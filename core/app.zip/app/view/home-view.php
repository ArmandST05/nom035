<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
</head>
<body>
      <div class="col-md-6 mb-3">
        <h3>Nuevo usuario</h3>
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Card title</h5>
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <a href="./?view=users/new" class="btn btn-success">Nuevo usuario</a>
          </div>
        </div>
      </div>
      <div class="col-md-6 mb-3">
        <h3>Encuesta</h3>
        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Card title</h5>
            <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
            <a href="" class="btn btn-success">Encuesta</a>
          </div>
        </div>
      </div>
</body>
</html>